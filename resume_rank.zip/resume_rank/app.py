import streamlit as st
from resume_parser import extract_resume_text
from scorer import score_resume

# ---------------- STATE ----------------
if "page" not in st.session_state:
    st.session_state.page = "login"

if "ranked" not in st.session_state:
    st.session_state.ranked = []

# ---------------- LOGIN PAGE ----------------
def login_page():
    st.markdown("""
        <style>
        /* Full app background */
        .stApp {
            background-color: #000000;
        }

        .login-box {
            max-width: 460px;
            margin: auto;
            padding: 36px;
            background-color: #ffffff;
            border-radius: 18px;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.15);
        }

        .login-title {
            text-align: center;
            color: #000000;
            font-size: 30px;
            font-weight: 700;
        }

        .login-subtitle {
            text-align: center;
            color: #000000;
            margin-bottom: 22px;
            font-size: 14px;
        }

        /* 🔧 ONLY FIX: password text color */
        input[type="password"] {
            color: white !important;
        }
        </style>
    """, unsafe_allow_html=True)

    st.markdown("""
        <div class="login-box">
            <div class="login-title">Resume Ranker AI</div>
            <div class="login-subtitle">
                Simple. Fair. Intelligent resume ranking.
            </div>
        </div>
    """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    email = st.text_input("Email")
    password = st.text_input("Password", type="password")

    st.markdown("<br>", unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1,2,1])
    with col2:
        if st.button("Login", use_container_width=True):
            st.session_state.user = email
            st.session_state.page = "rank"
            st.rerun()

# ---------------- RANK PAGE ----------------
def rank_page():
    st.markdown("""
        <style>
        .stApp {
            background-color: #000000;
        }
        </style>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns([6,1])
    with col1:
        st.markdown(
            f"<span style='color:white;'>👤 {st.session_state.user}</span>",
            unsafe_allow_html=True
        )
    with col2:
        if st.button("Logout"):
            st.session_state.page = "login"
            st.session_state.ranked = []
            st.rerun()

    st.markdown(
        "<h1 style='color:white;'>Resume Ranking System</h1>",
        unsafe_allow_html=True
    )
    st.markdown(
        "<p style='color:white;'>Upload multiple resumes and rank candidates based on project relevance</p>",
        unsafe_allow_html=True
    )

    job_role = st.selectbox(
        "Select Job Role",
        ["Data Scientist", "AI Engineer", "ML Engineer", "Web Developer"]
    )

    files = st.file_uploader(
        "Upload resumes (PDF / DOCX)",
        type=["pdf", "docx"],
        accept_multiple_files=True
    )

    if st.button("Analyze & Rank"):
        results = []

        for f in files:
            text = extract_resume_text(f)
            score_data = score_resume(text, job_role)

            if isinstance(score_data, dict):
                score = score_data.get("score", 0)
            else:
                score = score_data

            results.append({
                "Name": f.name,
                "Score": float(score)
            })

        st.session_state.ranked = sorted(
            results, key=lambda x: x["Score"], reverse=True
        )

    if st.session_state.ranked:
        st.markdown(
            "<h3 style='color:white;'>Ranking Results</h3>",
            unsafe_allow_html=True
        )

        for i, r in enumerate(st.session_state.ranked, start=1):
            st.markdown(
                f"""
                <div style="
                    background-color:white;
                    color:black;
                    padding:14px;
                    border-radius:12px;
                    margin-bottom:10px;
                ">
                    <b>{i}. {r['Name']}</b><br>
                    Score: {r['Score']}
                </div>
                """,
                unsafe_allow_html=True
            )

# ---------------- ROUTER ----------------
if st.session_state.page == "login":
    login_page()
else:
    rank_page()
