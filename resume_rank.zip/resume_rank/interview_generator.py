import subprocess

def generate_questions(resume_text, job_role):
    prompt = f"""
Generate 5 technical interview questions for a candidate
based on their resume and the role {job_role}.
Questions should be practical and project-based.
"""

    result = subprocess.run(
        ["ollama", "run", "phi"],
        input=prompt + resume_text[:2000],
        capture_output=True,
        text=True,
        encoding="utf-8"
    )

    return result.stdout.strip()
