from llm_analyzer import analyze_with_ollama

def score_resume(resume_text, job_role):
    result = analyze_with_ollama(resume_text, job_role)

    return {
        "score": result["score"],
        "summary": result["summary"]
    }
