import pdfplumber
import docx


# -----------------------------
# Resume text extraction
# -----------------------------

def extract_text_from_pdf(file):
    text = ""
    with pdfplumber.open(file) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
    return text


def extract_text_from_docx(file):
    document = docx.Document(file)
    return "\n".join([para.text for para in document.paragraphs])


def extract_resume_text(file):
    """
    Detect file type and extract text
    """
    filename = file.name.lower()

    if filename.endswith(".pdf"):
        return extract_text_from_pdf(file)

    elif filename.endswith(".docx"):
        return extract_text_from_docx(file)

    return ""


# -----------------------------
# LLM / Analyzer (dummy for now)
# -----------------------------

def analyze_with_ollama(resume_text, job_description=""):
    """
    Dummy analyzer.
    Replace this function later with real Ollama call.
    """

    if not resume_text.strip():
        return {
            "score": 0,
            "summary": "Empty or unreadable resume."
        }

    # Simple scoring logic (fast & stable)
    length_score = min(70, len(resume_text) // 40)
    role_bonus = min(30, len(job_description) * 2)

    final_score = min(100, length_score + role_bonus)

    summary = (
        "Resume analyzed successfully. "
        "Candidate shows relevant experience and skills "
        "based on resume content."
    )

    return {
        "score": final_score,
        "summary": summary
    }
